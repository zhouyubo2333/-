package accountSystem;
import user.*;
public interface AccountSystem {
	
	public User produce(String phonenumber);

}
