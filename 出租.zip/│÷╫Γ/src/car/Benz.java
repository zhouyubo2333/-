package car;

public class Benz implements car{
public double fei() {
	double s=2.5;
	
	System.out.println(s+"  Ԫ/Сʱ");
	return s;
}
}
